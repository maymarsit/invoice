'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { FileUpload } from '@/components/upload/FileUpload';
import { StatsCard } from '@/components/ui/StatsCard';
import { InvoiceCard } from '@/components/ui/InvoiceCard';
import { 
  FileCheck, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp,
  Upload,
  LogOut,
  Settings,
  BarChart3,
  Search,
  Filter,
  X,
} from 'lucide-react';
import { Invoice, InvoiceType, DashboardStats } from '@/types';

export default function DashboardPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [userName, setUserName] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCriticality, setFilterCriticality] = useState<string>('all');

  useEffect(() => {
    checkAuth();
    loadDashboardData();
  }, []);

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      router.push('/login');
      return;
    }

    // Get user profile
    const { data: profile } = await supabase
      .from('profiles')
      .select('full_name')
      .eq('id', user.id)
      .single();

    if (profile) {
      setUserName(profile.full_name || user.email?.split('@')[0] || 'Benutzer');
    }
  };

  const loadDashboardData = async () => {
    try {
      const response = await fetch('/api/dashboard');
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error('Error loading dashboard:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileSelect = async (file: File, invoiceType: InvoiceType) => {
    setIsUploading(true);

    try {
      // Upload file
      const formData = new FormData();
      formData.append('file', file);
      formData.append('invoice_type', invoiceType);

      const uploadResponse = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!uploadResponse.ok) {
        const error = await uploadResponse.json();
        throw new Error(error.error || 'Upload fehlgeschlagen');
      }

      const { invoice_id } = await uploadResponse.json();

      // Start analysis
      const analyzeResponse = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ invoice_id }),
      });

      if (!analyzeResponse.ok) {
        throw new Error('Analyse fehlgeschlagen');
      }

      // Reload data
      await loadDashboardData();
      setShowUploadModal(false);
      
    } catch (error) {
      console.error('Upload error:', error);
      alert(error instanceof Error ? error.message : 'Ein Fehler ist aufgetreten');
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteInvoice = async (invoiceId: string) => {
    if (!confirm('Möchten Sie diese Rechnung wirklich löschen?')) {
      return;
    }

    try {
      const response = await fetch(`/api/invoices/${invoiceId}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Löschen fehlgeschlagen');
      }

      await loadDashboardData();
    } catch (error) {
      console.error('Delete error:', error);
      alert('Fehler beim Löschen der Rechnung');
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push('/login');
  };

  const filteredInvoices = stats?.recent_invoices?.filter((invoice) => {
    const matchesSearch = invoice.file_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         invoice.invoice_number?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterCriticality === 'all' || invoice.criticality === filterCriticality;
    return matchesSearch && matchesFilter;
  }) || [];

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="spinner-lg mx-auto mb-4" />
          <p className="text-gray-600">Dashboard wird geladen...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary-600 rounded-lg flex items-center justify-center">
                <FileCheck className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Rechnungsprüfer</h1>
                <p className="text-xs text-gray-500">Dashboard</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="hidden sm:block text-right">
                <p className="text-sm font-medium text-gray-900">{userName}</p>
                <p className="text-xs text-gray-500">Angemeldet</p>
              </div>

              <button
                onClick={() => setShowUploadModal(true)}
                className="btn btn-primary btn-md"
              >
                <Upload className="w-4 h-4 mr-2" />
                Hochladen
              </button>

              <button
                onClick={handleLogout}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                title="Abmelden"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            Willkommen zurück, {userName}!
          </h2>
          <p className="text-gray-600">
            Hier ist eine Übersicht Ihrer Rechnungsprüfungen
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            title="Gesamte Rechnungen"
            value={stats?.total_invoices || 0}
            icon={<FileCheck className="w-6 h-6" />}
            color="primary"
          />
          
          <StatsCard
            title="Gut bewertet"
            value={stats?.good_invoices || 0}
            icon={<CheckCircle className="w-6 h-6" />}
            color="success"
          />
          
          <StatsCard
            title="Mit Warnungen"
            value={stats?.warning_invoices || 0}
            icon={<AlertTriangle className="w-6 h-6" />}
            color="warning"
          />
          
          <StatsCard
            title="Kritische Probleme"
            value={stats?.critical_invoices || 0}
            icon={<AlertTriangle className="w-6 h-6" />}
            color="danger"
          />
        </div>

        {/* Average Score Card */}
        {stats && stats.total_invoices > 0 && (
          <div className="card p-6 mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Durchschnittliche Bewertung
                </h3>
                <div className="flex items-baseline space-x-2">
                  <span className="text-4xl font-bold text-primary-600">
                    {Math.round(stats.average_score)}
                  </span>
                  <span className="text-gray-500">/ 100</span>
                </div>
              </div>
              <div className="w-24 h-24 rounded-full bg-primary-100 flex items-center justify-center">
                <BarChart3 className="w-12 h-12 text-primary-600" />
              </div>
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Rechnung suchen..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input pl-11 w-full"
              />
            </div>

            <div className="flex items-center space-x-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <select
                value={filterCriticality}
                onChange={(e) => setFilterCriticality(e.target.value)}
                className="input w-auto"
              >
                <option value="all">Alle Status</option>
                <option value="gut">Gut</option>
                <option value="warnung">Warnung</option>
                <option value="kritisch">Kritisch</option>
              </select>
            </div>
          </div>
        </div>

        {/* Recent Invoices */}
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Letzte Rechnungen
          </h3>

          {filteredInvoices.length === 0 ? (
            <div className="card p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileCheck className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Keine Rechnungen gefunden
              </h3>
              <p className="text-gray-600 mb-6">
                {searchTerm || filterCriticality !== 'all' 
                  ? 'Keine Rechnungen entsprechen Ihren Filterkriterien.'
                  : 'Laden Sie Ihre erste Rechnung hoch, um zu beginnen.'
                }
              </p>
              {!searchTerm && filterCriticality === 'all' && (
                <button
                  onClick={() => setShowUploadModal(true)}
                  className="btn btn-primary btn-md"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  Erste Rechnung hochladen
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredInvoices.map((invoice) => (
                <InvoiceCard
                  key={invoice.id}
                  invoice={invoice}
                  onDelete={handleDeleteInvoice}
                />
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto animate-slide-up">
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">
                Neue Rechnung hochladen
              </h2>
              <button
                onClick={() => setShowUploadModal(false)}
                disabled={isUploading}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6">
              <FileUpload
                onFileSelect={handleFileSelect}
                isUploading={isUploading}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
