import { NextRequest, NextResponse } from 'next/server';
import { getServiceSupabase } from '@/lib/supabase';
import { processDocumentWithAI, extractInvoiceFields } from '@/lib/documentai';
import {
  analyzeInvoiceWithAI,
  calculateOverallScore,
  determineCriticality,
  generateIssues,
} from '@/lib/openai-analysis';

export const dynamic = 'force-dynamic';
export const maxDuration = 300; // 5 minutes for processing

export async function POST(request: NextRequest) {
  try {
    const { invoice_id } = await request.json();

    if (!invoice_id) {
      return NextResponse.json(
        { error: 'Invoice ID ist erforderlich' },
        { status: 400 }
      );
    }

    const supabase = getServiceSupabase();

    // Get invoice
    const { data: invoice, error: fetchError } = await supabase
      .from('invoices')
      .select('*')
      .eq('id', invoice_id)
      .single();

    if (fetchError || !invoice) {
      return NextResponse.json(
        { error: 'Rechnung nicht gefunden' },
        { status: 404 }
      );
    }

    // Update status to processing
    await supabase
      .from('invoices')
      .update({ status: 'processing' })
      .eq('id', invoice_id);

    try {
      // Download file from storage
      const { data: fileData, error: downloadError } = await supabase.storage
        .from('invoices')
        .download(invoice.file_path);

      if (downloadError || !fileData) {
        throw new Error('Fehler beim Herunterladen der Datei');
      }

      // Convert to buffer
      const buffer = Buffer.from(await fileData.arrayBuffer());

      // Step 1: Process with Google Document AI
      console.log('Processing with Document AI...');
      const ocrData = await processDocumentWithAI(buffer, invoice.file_type);

      // Step 2: Extract invoice fields
      console.log('Extracting invoice fields...');
      const extractedFields = extractInvoiceFields(ocrData);

      // Step 3: Analyze with OpenAI
      console.log('Analyzing with OpenAI...');
      const analysisData = await analyzeInvoiceWithAI(ocrData, extractedFields);

      // Step 4: Calculate overall score
      const overallScore = calculateOverallScore(analysisData);
      const criticality = determineCriticality(overallScore);

      // Step 5: Generate issues list
      const issues = generateIssues(analysisData, extractedFields);

      // Step 6: Update invoice with results
      const { data: updatedInvoice, error: updateError } = await supabase
        .from('invoices')
        .update({
          invoice_number: extractedFields.invoice_number,
          invoice_date: extractedFields.invoice_date,
          due_date: extractedFields.due_date,
          supplier_name: extractedFields.supplier_name,
          supplier_address: extractedFields.supplier_address,
          supplier_ust_id: extractedFields.supplier_ust_id,
          customer_name: extractedFields.customer_name,
          customer_address: extractedFields.customer_address,
          customer_ust_id: extractedFields.customer_ust_id,
          net_amount: extractedFields.net_amount,
          tax_amount: extractedFields.tax_amount,
          tax_rate: extractedFields.tax_rate,
          gross_amount: extractedFields.gross_amount,
          overall_score: overallScore,
          criticality: criticality,
          status: 'completed',
          raw_ocr_data: ocrData,
          analysis_data: analysisData,
          issues: issues,
          processed_at: new Date().toISOString(),
        })
        .eq('id', invoice_id)
        .select()
        .single();

      if (updateError) {
        throw new Error('Fehler beim Aktualisieren der Rechnung');
      }

      // Log the action
      await supabase.from('audit_logs').insert({
        user_id: invoice.user_id,
        invoice_id: invoice_id,
        action: 'invoice_analyzed',
        details: {
          overall_score: overallScore,
          criticality: criticality,
          issues_count: issues.length,
        },
        ip_address: request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip'),
        user_agent: request.headers.get('user-agent'),
      });

      return NextResponse.json({
        success: true,
        invoice: updatedInvoice,
        message: 'Rechnung erfolgreich analysiert',
      });

    } catch (processingError) {
      console.error('Processing error:', processingError);

      // Update status to failed
      await supabase
        .from('invoices')
        .update({
          status: 'failed',
          issues: [{
            category: 'Verarbeitung',
            severity: 'kritisch',
            description: processingError instanceof Error 
              ? processingError.message 
              : 'Fehler bei der Verarbeitung',
          }],
        })
        .eq('id', invoice_id);

      throw processingError;
    }

  } catch (error) {
    console.error('Analyze API error:', error);
    return NextResponse.json(
      {
        error: error instanceof Error ? error.message : 'Ein unerwarteter Fehler ist aufgetreten',
      },
      { status: 500 }
    );
  }
}
