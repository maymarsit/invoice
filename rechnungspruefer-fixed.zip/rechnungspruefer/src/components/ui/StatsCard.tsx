import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color: 'primary' | 'success' | 'warning' | 'danger';
  trend?: {
    value: number;
    isPositive: boolean;
  };
}

export const StatsCard: React.FC<StatsCardProps> = ({
  title,
  value,
  icon,
  color,
  trend,
}) => {
  const colorClasses = {
    primary: {
      bg: 'bg-primary-100',
      text: 'text-primary-600',
      icon: 'bg-primary-600',
    },
    success: {
      bg: 'bg-success-100',
      text: 'text-success-600',
      icon: 'bg-success-600',
    },
    warning: {
      bg: 'bg-warning-100',
      text: 'text-warning-600',
      icon: 'bg-warning-600',
    },
    danger: {
      bg: 'bg-danger-100',
      text: 'text-danger-600',
      icon: 'bg-danger-600',
    },
  };

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-gray-600 mb-1">{title}</p>
          <p className="text-3xl font-bold text-gray-900">{value}</p>
          
          {trend && (
            <div className="flex items-center mt-2">
              {trend.isPositive ? (
                <TrendingUp className="w-4 h-4 text-success-600 mr-1" />
              ) : (
                <TrendingDown className="w-4 h-4 text-danger-600 mr-1" />
              )}
              <span
                className={`text-sm font-medium ${
                  trend.isPositive ? 'text-success-600' : 'text-danger-600'
                }`}
              >
                {trend.isPositive ? '+' : ''}{trend.value}%
              </span>
              <span className="text-sm text-gray-500 ml-1">vs. letzter Monat</span>
            </div>
          )}
        </div>
        
        <div className={`w-14 h-14 rounded-xl ${colorClasses[color].icon} flex items-center justify-center text-white`}>
          {icon}
        </div>
      </div>
    </div>
  );
};
