'use client';

import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, File, X, AlertCircle } from 'lucide-react';
import { InvoiceType } from '@/types';

interface FileUploadProps {
  onFileSelect: (file: File, invoiceType: InvoiceType) => void;
  isUploading?: boolean;
  maxSize?: number;
}

export const FileUpload: React.FC<FileUploadProps> = ({
  onFileSelect,
  isUploading = false,
  maxSize = 10 * 1024 * 1024, // 10MB
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [invoiceType, setInvoiceType] = useState<InvoiceType>('eingangsrechnung');
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setError(null);
    
    if (acceptedFiles.length === 0) {
      setError('Bitte wählen Sie eine gültige Datei (PDF, PNG, JPEG)');
      return;
    }

    const file = acceptedFiles[0];
    
    if (file.size > maxSize) {
      setError(`Datei ist zu groß. Maximum: ${maxSize / 1024 / 1024}MB`);
      return;
    }

    setSelectedFile(file);
  }, [maxSize]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'image/png': ['.png'],
      'image/jpeg': ['.jpg', '.jpeg'],
    },
    maxFiles: 1,
    disabled: isUploading,
  });

  const handleUpload = () => {
    if (selectedFile) {
      onFileSelect(selectedFile, invoiceType);
    }
  };

  const handleRemove = () => {
    setSelectedFile(null);
    setError(null);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  return (
    <div className="w-full">
      {/* Invoice Type Selection */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Rechnungstyp
        </label>
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setInvoiceType('eingangsrechnung')}
            disabled={isUploading}
            className={`p-3 rounded-lg border-2 transition-all ${
              invoiceType === 'eingangsrechnung'
                ? 'border-primary-600 bg-primary-50 text-primary-700'
                : 'border-gray-200 hover:border-gray-300 text-gray-700'
            }`}
          >
            <div className="font-medium">Eingangsrechnung</div>
            <div className="text-xs text-gray-500 mt-1">Erhaltene Rechnung</div>
          </button>
          
          <button
            type="button"
            onClick={() => setInvoiceType('ausgangsrechnung')}
            disabled={isUploading}
            className={`p-3 rounded-lg border-2 transition-all ${
              invoiceType === 'ausgangsrechnung'
                ? 'border-primary-600 bg-primary-50 text-primary-700'
                : 'border-gray-200 hover:border-gray-300 text-gray-700'
            }`}
          >
            <div className="font-medium">Ausgangsrechnung</div>
            <div className="text-xs text-gray-500 mt-1">Erstellte Rechnung</div>
          </button>
        </div>
      </div>

      {/* File Drop Zone */}
      {!selectedFile ? (
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
            isDragActive
              ? 'border-primary-500 bg-primary-50'
              : 'border-gray-300 hover:border-primary-400 hover:bg-gray-50'
          } ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <input {...getInputProps()} />
          
          <div className="flex flex-col items-center">
            <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mb-4">
              <Upload className="w-8 h-8 text-primary-600" />
            </div>
            
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {isDragActive ? 'Datei hier ablegen' : 'Rechnung hochladen'}
            </h3>
            
            <p className="text-sm text-gray-600 mb-4">
              Ziehen Sie eine Datei hierher oder klicken Sie zum Auswählen
            </p>
            
            <div className="flex items-center space-x-4 text-xs text-gray-500">
              <span>PDF, PNG, JPEG</span>
              <span>•</span>
              <span>Max. {maxSize / 1024 / 1024}MB</span>
            </div>
          </div>
        </div>
      ) : (
        <div className="border-2 border-gray-200 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center">
                <File className="w-6 h-6 text-primary-600" />
              </div>
              
              <div>
                <p className="font-medium text-gray-900">{selectedFile.name}</p>
                <p className="text-sm text-gray-500">{formatFileSize(selectedFile.size)}</p>
              </div>
            </div>
            
            {!isUploading && (
              <button
                onClick={handleRemove}
                className="p-2 text-gray-400 hover:text-danger-600 hover:bg-danger-50 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
          
          <button
            onClick={handleUpload}
            disabled={isUploading}
            className="btn btn-primary w-full mt-4"
          >
            {isUploading ? (
              <div className="flex items-center justify-center">
                <div className="spinner-sm mr-2" />
                <span>Wird hochgeladen und analysiert...</span>
              </div>
            ) : (
              <span>Hochladen und analysieren</span>
            )}
          </button>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="alert-danger mt-4 flex items-start">
          <AlertCircle className="w-5 h-5 mr-2 flex-shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}
    </div>
  );
};
