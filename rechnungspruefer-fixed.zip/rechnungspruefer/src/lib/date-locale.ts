// Re-export date-fns/locale to avoid import issues
export { de } from 'date-fns/locale';
