import { DocumentProcessorServiceClient } from '@google-cloud/documentai';

// Initialize Google Document AI client with credentials from environment
const getDocumentAIClient = () => {
  try {
    const credentials = JSON.parse(process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON || '{}');
    
    const client = new DocumentProcessorServiceClient({
      credentials: credentials,
      projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
    });
    
    return client;
  } catch (error) {
    console.error('Failed to initialize Document AI client:', error);
    throw new Error('Document AI initialization failed');
  }
};

// Process document with Google Document AI
export const processDocumentWithAI = async (fileBuffer: Buffer, mimeType: string) => {
  try {
    const client = getDocumentAIClient();
    const projectId = process.env.GOOGLE_CLOUD_PROJECT_ID;
    const processorId = process.env.GOOGLE_DOCUMENT_AI_PROCESSOR_ID;
    
    if (!projectId || !processorId) {
      throw new Error('Missing Google Cloud configuration');
    }
    
    // Construct the processor name
    const name = `projects/${projectId}/locations/eu/processors/${processorId}`;
    
    // Encode file buffer to base64
    const encodedFile = fileBuffer.toString('base64');
    
    // Prepare the request
    const request = {
      name,
      rawDocument: {
        content: encodedFile,
        mimeType: mimeType,
      },
    };
    
    // Process the document
    const [result] = await client.processDocument(request);
    const { document } = result;
    
    if (!document) {
      throw new Error('No document returned from Document AI');
    }
    
    // Extract text and entities
    const extractedData = {
      text: document.text || '',
      entities: extractEntities(document),
      pages: document.pages?.length || 0,
      confidence: calculateAverageConfidence(document),
    };
    
    return extractedData;
  } catch (error) {
    console.error('Document AI processing error:', error);
    throw new Error(`Document processing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
};

// Extract entities from the document
const extractEntities = (document: any) => {
  const entities: any = {};
  
  if (document.entities) {
    for (const entity of document.entities) {
      const type = entity.type || 'unknown';
      const mentionText = entity.mentionText || '';
      const confidence = entity.confidence || 0;
      
      // Only include entities with confidence > 0.5
      if (confidence > 0.5) {
        if (!entities[type]) {
          entities[type] = [];
        }
        entities[type].push({
          text: mentionText,
          confidence: confidence,
        });
      }
    }
  }
  
  return entities;
};

// Calculate average confidence score
const calculateAverageConfidence = (document: any): number => {
  let totalConfidence = 0;
  let count = 0;
  
  if (document.entities) {
    for (const entity of document.entities) {
      if (entity.confidence) {
        totalConfidence += entity.confidence;
        count++;
      }
    }
  }
  
  return count > 0 ? totalConfidence / count : 0;
};

// Extract invoice-specific fields from OCR data
export const extractInvoiceFields = (ocrData: any) => {
  const entities = ocrData.entities || {};
  const text = ocrData.text || '';
  
  // Helper function to get first entity value
  const getEntityValue = (entityType: string): string | null => {
    const entityArray = entities[entityType];
    if (entityArray && entityArray.length > 0) {
      return entityArray[0].text;
    }
    return null;
  };
  
  // Extract fields
  const fields = {
    invoice_number: getEntityValue('invoice_number') || extractInvoiceNumber(text),
    invoice_date: getEntityValue('invoice_date') || extractDate(text, 'Rechnungsdatum'),
    due_date: getEntityValue('due_date') || extractDate(text, 'Fälligkeitsdatum'),
    supplier_name: getEntityValue('supplier_name') || extractSupplierName(text),
    supplier_address: getEntityValue('supplier_address'),
    supplier_ust_id: getEntityValue('supplier_tax_id') || extractUStID(text),
    customer_name: getEntityValue('receiver_name'),
    customer_address: getEntityValue('receiver_address'),
    customer_ust_id: extractCustomerUStID(text),
    net_amount: extractAmount(text, 'Nettobetrag') || extractAmount(text, 'Zwischensumme'),
    tax_amount: extractAmount(text, 'MwSt') || extractAmount(text, 'Umsatzsteuer'),
    tax_rate: extractTaxRate(text),
    gross_amount: extractAmount(text, 'Gesamtbetrag') || extractAmount(text, 'Bruttobetrag'),
  };
  
  return fields;
};

// Helper functions for field extraction
const extractInvoiceNumber = (text: string): string | null => {
  const patterns = [
    /Rechnungsnummer[:\s]+([A-Z0-9-]+)/i,
    /Rechnung[:\s]+([A-Z0-9-]+)/i,
    /Invoice[:\s]+([A-Z0-9-]+)/i,
    /RE[:\s]+([A-Z0-9-]+)/i,
  ];
  
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) return match[1];
  }
  
  return null;
};

const extractDate = (text: string, label: string): string | null => {
  const pattern = new RegExp(`${label}[:\\s]+(\\d{1,2}[./-]\\d{1,2}[./-]\\d{2,4})`, 'i');
  const match = text.match(pattern);
  
  if (match) {
    return normalizeDate(match[1]);
  }
  
  return null;
};

const normalizeDate = (dateStr: string): string => {
  // Convert DD.MM.YYYY or DD/MM/YYYY to YYYY-MM-DD
  const parts = dateStr.split(/[./-]/);
  if (parts.length === 3) {
    const day = parts[0].padStart(2, '0');
    const month = parts[1].padStart(2, '0');
    let year = parts[2];
    
    // Convert 2-digit year to 4-digit
    if (year.length === 2) {
      year = parseInt(year) > 50 ? `19${year}` : `20${year}`;
    }
    
    return `${year}-${month}-${day}`;
  }
  
  return dateStr;
};

const extractSupplierName = (text: string): string | null => {
  // Try to extract company name from the top of the document
  const lines = text.split('\n').slice(0, 10);
  
  for (const line of lines) {
    if (line.length > 3 && line.length < 100 && /[A-Za-zäöüÄÖÜß]/.test(line)) {
      return line.trim();
    }
  }
  
  return null;
};

const extractUStID = (text: string): string | null => {
  const patterns = [
    /USt[-.]?IdNr\.?[:\s]+(DE\d{9})/i,
    /Umsatzsteuer[-.]?ID[:\s]+(DE\d{9})/i,
    /Steuernummer[:\s]+(DE\d{9})/i,
    /(DE\d{9})/,
  ];
  
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) return match[1];
  }
  
  return null;
};

const extractCustomerUStID = (text: string): string | null => {
  // Similar to extractUStID but looks for customer section
  const customerSection = text.match(/Rechnungsempfänger[:\s]+([\s\S]{0,200})/i);
  if (customerSection) {
    return extractUStID(customerSection[1]);
  }
  return null;
};

const extractAmount = (text: string, label: string): number | null => {
  const pattern = new RegExp(`${label}[:\\s]+([\\d.,]+)\\s*€?`, 'i');
  const match = text.match(pattern);
  
  if (match) {
    const amountStr = match[1].replace(/\./g, '').replace(',', '.');
    return parseFloat(amountStr);
  }
  
  return null;
};

const extractTaxRate = (text: string): number | null => {
  const pattern = /(\d{1,2})\s*%\s*MwSt/i;
  const match = text.match(pattern);
  
  if (match) {
    return parseFloat(match[1]);
  }
  
  return 19; // Default German VAT rate
};
