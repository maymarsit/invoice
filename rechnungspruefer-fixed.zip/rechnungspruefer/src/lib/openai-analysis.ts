import OpenAI from 'openai';
import { AnalysisData, Issue, CriticalityLevel } from '@/types';

// Initialize OpenAI client
const getOpenAIClient = () => {
  const apiKey = process.env.OPENAI_API_KEY;
  
  if (!apiKey) {
    throw new Error('OpenAI API key is not configured');
  }
  
  return new OpenAI({
    apiKey: apiKey,
  });
};

// Analyze invoice with GPT-4 Mini
export const analyzeInvoiceWithAI = async (
  ocrData: any,
  extractedFields: any
): Promise<AnalysisData> => {
  try {
    const openai = getOpenAIClient();
    
    // Prepare the analysis prompt
    const prompt = createAnalysisPrompt(ocrData, extractedFields);
    
    // Call GPT-4 Mini for analysis
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: getSystemPrompt(),
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: 0.3,
      max_tokens: 2000,
      response_format: { type: 'json_object' },
    });
    
    const analysisResult = response.choices[0].message.content;
    
    if (!analysisResult) {
      throw new Error('No response from OpenAI');
    }
    
    // Parse the JSON response
    const parsedAnalysis = JSON.parse(analysisResult);
    
    // Calculate scores and create analysis data
    const analysisData = createAnalysisData(parsedAnalysis, extractedFields);
    
    return analysisData;
  } catch (error) {
    console.error('OpenAI analysis error:', error);
    throw new Error(`Invoice analysis failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
};

// Create system prompt for GPT-4 Mini
const getSystemPrompt = (): string => {
  return `Du bist ein Experte für deutsche Rechnungsprüfung und Buchhaltung. Deine Aufgabe ist es, Rechnungen gemäß den deutschen gesetzlichen Anforderungen zu analysieren und zu bewerten.

Prüfe folgende Aspekte:
1. Pflichtangaben nach § 14 UStG (Vollständiger Name und Anschrift, Steuernummer/USt-IdNr, Rechnungsnummer, Ausstellungsdatum, Leistungsbeschreibung, Entgelt, Steuersatz)
2. USt-IdNr Format und Validierung (DE + 9 Ziffern)
3. Mathematische Korrektheit (Netto + MwSt = Brutto)
4. Datumslogik (Rechnungsdatum vor Fälligkeitsdatum)
5. Format und Lesbarkeit

Antworte immer in validem JSON-Format mit deutscher Sprache für Beschreibungen.`;
};

// Create analysis prompt
const createAnalysisPrompt = (ocrData: any, extractedFields: any): string => {
  return `Analysiere diese deutsche Rechnung und prüfe sie auf Vollständigkeit und Korrektheit.

EXTRAHIERTE FELDER:
${JSON.stringify(extractedFields, null, 2)}

OCR TEXT (Auszug):
${ocrData.text?.substring(0, 2000) || 'Kein Text verfügbar'}

Gib eine detaillierte Analyse zurück im folgenden JSON-Format:
{
  "pflichtfelder_check": {
    "present": ["Liste der vorhandenen Pflichtfelder"],
    "missing": ["Liste der fehlenden Pflichtfelder"]
  },
  "ust_idnr_check": {
    "supplier_ust_id": "gefundene USt-IdNr oder null",
    "supplier_valid": true/false,
    "customer_ust_id": "gefundene USt-IdNr oder null",
    "customer_valid": true/false,
    "format_correct": true/false
  },
  "math_check": {
    "net_amount": Betrag oder null,
    "tax_amount": Betrag oder null,
    "gross_amount": Betrag oder null,
    "tax_rate": Prozentsatz oder null,
    "calculations_correct": true/false,
    "issues": ["Liste der mathematischen Probleme"]
  },
  "date_check": {
    "invoice_date": "Datum oder null",
    "due_date": "Datum oder null",
    "dates_valid": true/false,
    "issues": ["Liste der Datumsprobleme"]
  },
  "format_check": {
    "readable": true/false,
    "complete": true/false,
    "structured": true/false,
    "issues": ["Liste der Formatprobleme"]
  },
  "recommendations": ["Liste von Verbesserungsvorschlägen"]
}`;
};

// Create structured analysis data with scoring
const createAnalysisData = (parsedAnalysis: any, extractedFields: any): AnalysisData => {
  // Calculate individual scores
  const pflichtfelderScore = calculatePflichtfelderScore(parsedAnalysis.pflichtfelder_check);
  const ustIdNrScore = calculateUStIdNrScore(parsedAnalysis.ust_idnr_check);
  const mathScore = calculateMathScore(parsedAnalysis.math_check);
  const dateScore = calculateDateScore(parsedAnalysis.date_check);
  const formatScore = calculateFormatScore(parsedAnalysis.format_check);
  
  return {
    pflichtfelder_score: pflichtfelderScore,
    ust_idnr_score: ustIdNrScore,
    mathematik_score: mathScore,
    datum_score: dateScore,
    format_score: formatScore,
    pflichtfelder_details: {
      present: parsedAnalysis.pflichtfelder_check?.present || [],
      missing: parsedAnalysis.pflichtfelder_check?.missing || [],
    },
    ust_validation: {
      supplier_valid: parsedAnalysis.ust_idnr_check?.supplier_valid || false,
      customer_valid: parsedAnalysis.ust_idnr_check?.customer_valid || false,
      format_correct: parsedAnalysis.ust_idnr_check?.format_correct || false,
    },
    math_validation: {
      calculations_correct: parsedAnalysis.math_check?.calculations_correct || false,
      net_plus_tax_equals_gross: checkMathCorrectness(extractedFields),
      tax_rate_correct: parsedAnalysis.math_check?.tax_rate >= 0 && parsedAnalysis.math_check?.tax_rate <= 100,
      difference: calculateMathDifference(extractedFields),
    },
    date_validation: {
      invoice_date_present: !!extractedFields.invoice_date,
      due_date_valid: parsedAnalysis.date_check?.dates_valid || false,
      dates_logical: checkDatesLogical(extractedFields),
    },
    format_check: {
      readable: parsedAnalysis.format_check?.readable || false,
      complete: parsedAnalysis.format_check?.complete || false,
      structured: parsedAnalysis.format_check?.structured || false,
    },
    recommendations: parsedAnalysis.recommendations || [],
  };
};

// Scoring functions (each out of maximum points)
const calculatePflichtfelderScore = (check: any): number => {
  const requiredFields = [
    'Vollständiger Name und Anschrift',
    'Steuernummer oder USt-IdNr',
    'Rechnungsnummer',
    'Ausstellungsdatum',
    'Leistungsbeschreibung',
    'Entgelt',
    'Steuersatz',
  ];
  
  const presentCount = check?.present?.length || 0;
  const totalFields = requiredFields.length;
  
  return Math.round((presentCount / totalFields) * 30);
};

const calculateUStIdNrScore = (check: any): number => {
  let score = 0;
  
  if (check?.supplier_valid) score += 10;
  if (check?.customer_valid) score += 5;
  if (check?.format_correct) score += 5;
  
  return score;
};

const calculateMathScore = (check: any): number => {
  if (check?.calculations_correct) {
    return 25;
  }
  
  // Partial score if only minor issues
  if (check?.issues?.length === 1) {
    return 15;
  }
  
  return check?.issues?.length > 0 ? 5 : 0;
};

const calculateDateScore = (check: any): number => {
  if (check?.dates_valid) {
    return 10;
  }
  
  return check?.issues?.length === 1 ? 5 : 0;
};

const calculateFormatScore = (check: any): number => {
  let score = 0;
  
  if (check?.readable) score += 5;
  if (check?.complete) score += 5;
  if (check?.structured) score += 5;
  
  return score;
};

// Helper functions
const checkMathCorrectness = (fields: any): boolean => {
  if (!fields.net_amount || !fields.tax_amount || !fields.gross_amount) {
    return false;
  }
  
  const calculatedGross = fields.net_amount + fields.tax_amount;
  const difference = Math.abs(calculatedGross - fields.gross_amount);
  
  return difference < 0.02; // Allow 2 cents tolerance
};

const calculateMathDifference = (fields: any): number | undefined => {
  if (!fields.net_amount || !fields.tax_amount || !fields.gross_amount) {
    return undefined;
  }
  
  const calculatedGross = fields.net_amount + fields.tax_amount;
  return Math.abs(calculatedGross - fields.gross_amount);
};

const checkDatesLogical = (fields: any): boolean => {
  if (!fields.invoice_date || !fields.due_date) {
    return false;
  }
  
  const invoiceDate = new Date(fields.invoice_date);
  const dueDate = new Date(fields.due_date);
  
  return dueDate >= invoiceDate;
};

// Calculate overall score and determine criticality
export const calculateOverallScore = (analysisData: AnalysisData): number => {
  return (
    analysisData.pflichtfelder_score +
    analysisData.ust_idnr_score +
    analysisData.mathematik_score +
    analysisData.datum_score +
    analysisData.format_score
  );
};

export const determineCriticality = (score: number): CriticalityLevel => {
  if (score >= 71) return 'gut';
  if (score >= 41) return 'warnung';
  return 'kritisch';
};

// Generate issues list from analysis
export const generateIssues = (analysisData: AnalysisData, extractedFields: any): Issue[] => {
  const issues: Issue[] = [];
  
  // Pflichtfelder issues
  if (analysisData.pflichtfelder_details.missing.length > 0) {
    issues.push({
      category: 'Pflichtangaben',
      severity: 'kritisch',
      description: `Fehlende Pflichtangaben: ${analysisData.pflichtfelder_details.missing.join(', ')}`,
    });
  }
  
  // USt-IdNr issues
  if (!analysisData.ust_validation.supplier_valid) {
    issues.push({
      category: 'USt-IdNr',
      severity: 'warnung',
      description: 'Lieferanten USt-IdNr fehlt oder ist ungültig',
      field: 'supplier_ust_id',
    });
  }
  
  // Math issues
  if (!analysisData.math_validation.calculations_correct) {
    issues.push({
      category: 'Mathematik',
      severity: 'kritisch',
      description: 'Mathematische Berechnung ist fehlerhaft',
      details: analysisData.math_validation.difference 
        ? `Differenz: ${analysisData.math_validation.difference.toFixed(2)}€`
        : undefined,
    });
  }
  
  // Date issues
  if (!analysisData.date_validation.invoice_date_present) {
    issues.push({
      category: 'Datum',
      severity: 'kritisch',
      description: 'Rechnungsdatum fehlt',
      field: 'invoice_date',
    });
  }
  
  if (!analysisData.date_validation.dates_logical) {
    issues.push({
      category: 'Datum',
      severity: 'warnung',
      description: 'Fälligkeitsdatum liegt vor Rechnungsdatum',
    });
  }
  
  // Format issues
  if (!analysisData.format_check.readable) {
    issues.push({
      category: 'Format',
      severity: 'warnung',
      description: 'Rechnung ist schwer lesbar',
    });
  }
  
  return issues;
};
