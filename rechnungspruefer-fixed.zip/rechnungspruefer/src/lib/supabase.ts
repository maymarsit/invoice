import { createClient } from '@supabase/supabase-js';
import { createClientComponentClient, createServerComponentClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';

// Supabase configuration with validation
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

// Client-side Supabase client (uses anon key, safe for browser)
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

// Server-side Supabase client (uses service role key, NEVER expose to client)
// This should ONLY be used in API routes and server components
export const getServiceSupabase = () => {
  if (!supabaseServiceKey) {
    throw new Error('Missing Supabase service role key');
  }
  return createClient(supabaseUrl, supabaseServiceKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });
};

// Helper function to get Supabase client for server components
export const getServerSupabase = async () => {
  const cookieStore = cookies();
  return createServerComponentClient({ cookies: () => cookieStore });
};

// Helper function to get current user
export const getCurrentUser = async () => {
  const supabaseClient = await getServerSupabase();
  const { data: { user }, error } = await supabaseClient.auth.getUser();
  
  if (error || !user) {
    return null;
  }
  
  return user;
};

// Helper function to get current user's profile
export const getCurrentProfile = async () => {
  const user = await getCurrentUser();
  if (!user) return null;
  
  const supabaseClient = await getServerSupabase();
  const { data: profile, error } = await supabaseClient
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single();
  
  if (error) {
    console.error('Error fetching profile:', error);
    return null;
  }
  
  return profile;
};

// Helper function to check if user is admin
export const isAdmin = async () => {
  const profile = await getCurrentProfile();
  return profile?.role === 'admin';
};

// Storage helper functions
export const uploadFile = async (
  bucket: string,
  path: string,
  file: File,
  options?: { contentType?: string; cacheControl?: string }
) => {
  const { data, error } = await supabase.storage
    .from(bucket)
    .upload(path, file, {
      contentType: options?.contentType || file.type,
      cacheControl: options?.cacheControl || '3600',
      upsert: false,
    });
  
  if (error) {
    throw new Error(`File upload failed: ${error.message}`);
  }
  
  return data;
};

export const getFileUrl = (bucket: string, path: string) => {
  const { data } = supabase.storage
    .from(bucket)
    .getPublicUrl(path);
  
  return data.publicUrl;
};

export const downloadFile = async (bucket: string, path: string) => {
  const { data, error } = await supabase.storage
    .from(bucket)
    .download(path);
  
  if (error) {
    throw new Error(`File download failed: ${error.message}`);
  }
  
  return data;
};

export const deleteFile = async (bucket: string, path: string) => {
  const { error } = await supabase.storage
    .from(bucket)
    .remove([path]);
  
  if (error) {
    throw new Error(`File deletion failed: ${error.message}`);
  }
};

// Database helper functions with RLS enforcement
export const createInvoice = async (invoiceData: any) => {
  const { data, error } = await supabase
    .from('invoices')
    .insert(invoiceData)
    .select()
    .single();
  
  if (error) {
    throw new Error(`Failed to create invoice: ${error.message}`);
  }
  
  return data;
};

export const updateInvoice = async (invoiceId: string, updates: any) => {
  const { data, error } = await supabase
    .from('invoices')
    .update(updates)
    .eq('id', invoiceId)
    .select()
    .single();
  
  if (error) {
    throw new Error(`Failed to update invoice: ${error.message}`);
  }
  
  return data;
};

export const getInvoice = async (invoiceId: string) => {
  const { data, error } = await supabase
    .from('invoices')
    .select('*')
    .eq('id', invoiceId)
    .single();
  
  if (error) {
    throw new Error(`Failed to fetch invoice: ${error.message}`);
  }
  
  return data;
};

export const getUserInvoices = async (userId: string, limit = 10) => {
  const { data, error } = await supabase
    .from('invoices')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(limit);
  
  if (error) {
    throw new Error(`Failed to fetch invoices: ${error.message}`);
  }
  
  return data;
};

export const deleteInvoice = async (invoiceId: string) => {
  const { error } = await supabase
    .from('invoices')
    .delete()
    .eq('id', invoiceId);
  
  if (error) {
    throw new Error(`Failed to delete invoice: ${error.message}`);
  }
};

// Audit logging helper
export const logAction = async (
  userId: string,
  invoiceId: string | null,
  action: string,
  details: any,
  request?: Request
) => {
  const ipAddress = request?.headers.get('x-forwarded-for') || 
                    request?.headers.get('x-real-ip') || 
                    null;
  const userAgent = request?.headers.get('user-agent') || null;
  
  const { error } = await supabase
    .from('audit_logs')
    .insert({
      user_id: userId,
      invoice_id: invoiceId,
      action,
      details,
      ip_address: ipAddress,
      user_agent: userAgent,
    });
  
  if (error) {
    console.error('Failed to log action:', error);
  }
};
