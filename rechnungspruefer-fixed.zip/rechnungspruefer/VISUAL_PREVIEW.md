# 🎨 Rechnungsprüfer - Visual Preview

## 📱 Login Sayfası

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                    ┌──────────────┐                        │
│                    │  📄 File     │                        │
│                    │    Check     │                        │
│                    └──────────────┘                        │
│                                                             │
│                 Rechnungsprüfer                            │
│      Intelligente Rechnungsprüfung für Deutschland        │
│                                                             │
│    ┌───────────────────────────────────────────────┐      │
│    │  ┌──────────┐  ┌──────────────┐              │      │
│    │  │ Anmelden │  │ Registrieren │              │      │
│    │  └──────────┘  └──────────────┘              │      │
│    │                                               │      │
│    │  E-Mail-Adresse                              │      │
│    │  ┌─────────────────────────────────────┐    │      │
│    │  │ 📧 ihre.email@beispiel.de          │    │      │
│    │  └─────────────────────────────────────┘    │      │
│    │                                               │      │
│    │  Passwort                                     │      │
│    │  ┌─────────────────────────────────────┐    │      │
│    │  │ 🔒 ••••••••                     👁  │    │      │
│    │  └─────────────────────────────────────┘    │      │
│    │                                               │      │
│    │  ┌─────────────────────────────────────┐    │      │
│    │  │         Anmelden                    │    │      │
│    │  └─────────────────────────────────────┘    │      │
│    │                                               │      │
│    │           Passwort vergessen?                │      │
│    └───────────────────────────────────────────────┘      │
│                                                             │
│        ✓ GDPR-konform  ✓ Verschlüsselt  ✓ Made in DE      │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**Features:**
- ✅ Modern gradient background (primary-50 → white → primary-100)
- ✅ Smooth animations (fade-in, slide-up)
- ✅ Tab switching (Anmelden / Registrieren)
- ✅ Password visibility toggle
- ✅ Real-time validation
- ✅ Error/Success messages
- ✅ Loading states
- ✅ Mobile responsive

---

## 🏠 Dashboard Sayfası

```
┌──────────────────────────────────────────────────────────────────────┐
│ 📄 Rechnungsprüfer Dashboard    👤 Max Mustermann  [Hochladen] [🚪]│
├──────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  Willkommen zurück, Max Mustermann!                                 │
│  Hier ist eine Übersicht Ihrer Rechnungsprüfungen                   │
│                                                                      │
│  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐        │
│  │ 📄 Gesamte     │  │ ✅ Gut         │  │ ⚠️ Mit         │        │
│  │    125         │  │    98          │  │    21          │        │
│  │                │  │                │  │                │        │
│  └────────────────┘  └────────────────┘  └────────────────┘        │
│                                                                      │
│  ┌────────────────┐                                                 │
│  │ ⚠️ Kritische    │  Durchschnittliche Bewertung                   │
│  │    6           │  ┌──────────────────────────────┐              │
│  │                │  │   87 / 100         📊        │              │
│  └────────────────┘  └──────────────────────────────┘              │
│                                                                      │
│  🔍 Rechnung suchen...          [Filter: Alle Status ▼]            │
│                                                                      │
│  Letzte Rechnungen                                                  │
│                                                                      │
│  ┌──────────────────────────────────────────────────────┐          │
│  │ 📄 Rechnung_Januar_2025.pdf         [92] 🟢          │          │
│  │ Eingangsrechnung                                      │          │
│  │ Nr: RE-2025-001                                       │          │
│  │ 📅 Datum: 15.01.2025    💶 Betrag: 1.250,00€        │          │
│  │ ✅ Abgeschlossen                         👁 🗑️       │          │
│  └──────────────────────────────────────────────────────┘          │
│                                                                      │
│  ┌──────────────────────────────────────────────────────┐          │
│  │ 📄 Lieferung_Buero.pdf                  [58] 🟡      │          │
│  │ Eingangsrechnung                                      │          │
│  │ Nr: RE-2025-002                                       │          │
│  │ 📅 Datum: 18.01.2025    💶 Betrag: 3.450,00€        │          │
│  │ ⚠️ Warnung                               👁 🗑️       │          │
│  │ • Fehlende Pflichtangaben: Leistungsbeschreibung     │          │
│  └──────────────────────────────────────────────────────┘          │
│                                                                      │
│  ┌──────────────────────────────────────────────────────┐          │
│  │ 📄 Rechnung_Defekt.pdf                  [23] 🔴      │          │
│  │ Ausgangsrechnung                                      │          │
│  │ Nr: N/A                                               │          │
│  │ 📅 Datum: N/A           💶 Betrag: N/A              │          │
│  │ 🔴 Kritisch                              👁 🗑️       │          │
│  │ • Rechnungsnummer fehlt                               │          │
│  │ • Mathematische Berechnung ist fehlerhaft            │          │
│  └──────────────────────────────────────────────────────┘          │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

**Features:**
- ✅ Real-time statistics (4 stat cards)
- ✅ Average score display with icon
- ✅ Search & filter functionality
- ✅ Color-coded score badges
- ✅ Detailed invoice cards
- ✅ Quick actions (view, delete)
- ✅ Issue preview
- ✅ Sticky header

---

## 📤 Upload Modal

```
┌────────────────────────────────────────────┐
│  Neue Rechnung hochladen              ✕   │
├────────────────────────────────────────────┤
│                                            │
│  Rechnungstyp                              │
│  ┌──────────────────┐ ┌─────────────────┐ │
│  │ Eingangsrechnung │ │Ausgangsrechnung │ │
│  │ Erhaltene Rechnung│ │Erstellte Rechnung│ │
│  └──────────────────┘ └─────────────────┘ │
│                                            │
│  ┌────────────────────────────────────┐   │
│  │                                    │   │
│  │           📤                       │   │
│  │                                    │   │
│  │     Rechnung hochladen            │   │
│  │                                    │   │
│  │  Ziehen Sie eine Datei hierher   │   │
│  │  oder klicken Sie zum Auswählen   │   │
│  │                                    │   │
│  │  PDF, PNG, JPEG  •  Max. 10MB    │   │
│  │                                    │   │
│  └────────────────────────────────────┘   │
│                                            │
└────────────────────────────────────────────┘

Nach Upload:

┌────────────────────────────────────────────┐
│  📄 Rechnung_2025.pdf                     │
│     1.2 MB                           ✕    │
│                                            │
│  ┌────────────────────────────────────┐   │
│  │  Hochladen und analysieren        │   │
│  └────────────────────────────────────┘   │
└────────────────────────────────────────────┘
```

**Features:**
- ✅ Invoice type selection
- ✅ Drag & drop zone
- ✅ File preview
- ✅ Size display
- ✅ Remove option
- ✅ Upload progress
- ✅ Analysis status

---

## 🎨 Design System

### Renk Paleti

```
Primary (Mavi):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#0ea5e9  ████  Main buttons, links, active states
#0284c7  ████  Hover states
#0369a1  ████  Pressed states

Success (Yeşil):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#22c55e  ████  Good scores (71-100)
#16a34a  ████  Success messages

Warning (Sarı):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#f59e0b  ████  Warning scores (41-70)
#d97706  ████  Warning messages

Danger (Kırmızı):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#ef4444  ████  Critical scores (0-40)
#dc2626  ████  Error messages

Gray (Neutral):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#f9fafb  ████  Background
#e5e7eb  ████  Borders
#6b7280  ████  Text secondary
#111827  ████  Text primary
```

### Tipografi

```
Font Family: Inter (Google Fonts)

Headings:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
H1: 3xl (30px) - Bold - Rechnungsprüfer
H2: 2xl (24px) - Bold - Section titles
H3: xl (20px) - Semibold - Card titles

Body:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Base: base (16px) - Regular - Body text
Small: sm (14px) - Regular - Labels
Tiny: xs (12px) - Regular - Helper text
```

### Components

```
Buttons:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Primary:   [  Text  ]  Blue bg, white text
Secondary: [  Text  ]  Gray bg, dark text
Danger:    [  Text  ]  Red bg, white text

Sizes: sm (px-3 py-1.5), md (px-4 py-2), lg (px-6 py-3)

Cards:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌──────────────────┐
│  Content         │  White bg, rounded-xl
│  More content    │  Shadow-soft, border
└──────────────────┘

Hover: Shadow-medium, cursor pointer

Badges:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[Success]  Green bg, rounded-full
[Warning]  Yellow bg, rounded-full
[Danger]   Red bg, rounded-full

Inputs:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌──────────────────────────┐
│ Placeholder text         │  Border, rounded-lg
└──────────────────────────┘
Focus: Blue ring, blue border
```

### Animations

```
Fade In:
opacity: 0 → 1 (300ms ease-in-out)

Slide Up:
transform: translateY(10px) → 0
opacity: 0 → 1 (300ms ease-out)

Spinner:
Rotating border animation

Hover:
Scale: 1 → 1.02 (200ms)
Shadow: soft → medium (200ms)
```

---

## 📊 Score Badge Variants

```
Gut (71-100):
┌────────┐
│   92   │  Green background
└────────┘  Green text, green border
    Gut

Warnung (41-70):
┌────────┐
│   58   │  Yellow background
└────────┘  Yellow text, yellow border
  Warnung

Kritisch (0-40):
┌────────┐
│   23   │  Red background
└────────┘  Red text, red border
  Kritisch
```

**Sizes:**
- SM: 48x48px, text-lg
- MD: 64x64px, text-xl
- LG: 80x80px, text-2xl

---

## 🎯 User Flow

```
1. Landing (/)
   ↓
   Redirect to Login

2. Login (/login)
   ├─→ Register
   │   ↓
   │   Email confirmation
   │   ↓
   └── Login
       ↓
       Dashboard

3. Dashboard (/dashboard)
   ├─→ [Hochladen] → Upload Modal
   │   ↓
   │   Select Type
   │   ↓
   │   Choose File
   │   ↓
   │   Upload (POST /api/upload)
   │   ↓
   │   Analyze (POST /api/analyze)
   │   ↓
   │   Dashboard Refresh
   │
   ├─→ [👁 View] → Invoice Details
   │
   └─→ [🗑️ Delete] → Confirm → DELETE /api/invoices/[id]
```

---

## 🔄 Data Flow

```
Frontend (Next.js)
    ↓ User uploads PDF
    ↓
POST /api/upload
    ↓ Save to Supabase Storage
    ↓ Create invoice record
    ↓ Return invoice_id
    ↓
POST /api/analyze
    ↓ Download file
    ↓ Google Document AI (OCR)
    ↓ Extract invoice fields
    ↓ OpenAI GPT-4 Mini (Analysis)
    ↓ Calculate score
    ↓ Determine criticality
    ↓ Generate issues
    ↓ Update invoice record
    ↓
GET /api/dashboard
    ↓ Fetch statistics
    ↓ Fetch recent invoices
    ↓ Return to frontend
    ↓
Dashboard Display
```

---

## 📱 Responsive Design

### Desktop (1024px+)
```
┌─────────────────────────────────────────┐
│ Header: Logo | Title | Actions          │
├─────────────────────────────────────────┤
│ Stats: [Card] [Card] [Card] [Card]     │
│                                          │
│ Average Score Card                       │
│                                          │
│ Search & Filters                         │
│                                          │
│ Invoices: [Card] [Card] [Card]         │
│           [Card] [Card] [Card]         │
└─────────────────────────────────────────┘
```

### Tablet (768px - 1023px)
```
┌───────────────────────────┐
│ Header: Compressed        │
├───────────────────────────┤
│ Stats: [Card] [Card]     │
│        [Card] [Card]     │
│                           │
│ Average Score Card        │
│                           │
│ Search & Filters          │
│                           │
│ Invoices: [Card] [Card]  │
│           [Card] [Card]  │
└───────────────────────────┘
```

### Mobile (< 768px)
```
┌─────────────────┐
│ Header: Stack   │
├─────────────────┤
│ Stats: [Card]   │
│        [Card]   │
│        [Card]   │
│        [Card]   │
│                 │
│ Avg Score Card  │
│                 │
│ Search          │
│ Filters         │
│                 │
│ Invoice [Card]  │
│ Invoice [Card]  │
│ Invoice [Card]  │
└─────────────────┘
```

---

## 🎨 UI Screenshots Description

### Login Page
- **Background**: Smooth gradient from light blue to white
- **Logo**: Blue rounded square with FileCheck icon
- **Card**: White card with shadow, centered
- **Tabs**: Toggle between Login/Register
- **Inputs**: Icon on left, styled borders
- **Button**: Full-width blue button with hover effect
- **Footer**: Three checkmarks with features

### Dashboard
- **Header**: Sticky, white background, company logo + user info
- **Stats**: 4 cards in a row, different colors per metric
- **Average**: Large number with bar chart icon
- **Filters**: Search bar + dropdown
- **Invoices**: Grid of cards, 3 columns on desktop
- **Cards**: Score badge, file icon, details, action buttons

### Upload Modal
- **Overlay**: Semi-transparent black
- **Modal**: White, rounded corners, max-width
- **Type Selection**: Two buttons, one active
- **Upload Zone**: Dashed border, large target area
- **File Preview**: Shows filename, size, remove button

---

## ✨ Interactive Elements

### Hover States
- Buttons: Darker shade + shadow
- Cards: Lift effect (shadow-medium)
- Links: Underline + color change
- Action icons: Background color + icon color

### Loading States
- Spinner animation on buttons
- Skeleton screens on data load
- Progress bars on upload

### Transitions
- All: 200ms ease-in-out
- Modals: Fade in background, slide up content
- Tooltips: Fade in 150ms

---

## 🎯 Key Features Visualization

```
Invoice Analysis Pipeline:
═════════════════════════════════════════════════

PDF Upload → OCR → AI Analysis → Scoring → Display
   ↓         ↓         ↓           ↓         ↓
[📄File] [📝Text] [🤖GPT] [📊0-100] [🎨UI]

Score Calculation:
═════════════════════════════════════════════════

Pflichtfelder  ████████████████████████░░░░ 30p
USt-IdNr       ████████████████░░░░░░░░░░░░ 20p
Mathematik     █████████████████████████░░░ 25p
Datum          ██████████░░░░░░░░░░░░░░░░░░ 10p
Format         ███████████████░░░░░░░░░░░░░ 15p
               ─────────────────────────────
Total Score:   87 / 100  🟢 GUT
```

---

Bu visual preview, projenizin tüm önemli ekranlarını ve özelliklerini gösteriyor! 🎨
