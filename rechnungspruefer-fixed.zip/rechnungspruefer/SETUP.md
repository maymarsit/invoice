# Rechnungsprüfer - Detaillierte Installationsanleitung

## 📋 Schritt-für-Schritt Setup

### 1. Supabase Projekt erstellen

#### a) Account und Projekt erstellen
1. Gehen Sie zu [supabase.com](https://supabase.com)
2. Erstellen Sie einen Account (falls noch nicht vorhanden)
3. Klicken Sie auf "New Project"
4. Wählen Sie:
   - Organization: Ihre Organisation
   - Name: `rechnungspruefer`
   - Database Password: Sicheres Passwort generieren und speichern
   - Region: `Europe (Frankfurt)` für GDPR-Compliance
   - Pricing Plan: Free oder Pro (je nach Bedarf)

#### b) API Keys kopieren
1. Gehen Sie zu "Project Settings" > "API"
2. Kopieren Sie:
   - **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
   - **anon/public key** → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **service_role key** → `SUPABASE_SERVICE_ROLE_KEY` (⚠️ NIEMALS im Frontend verwenden!)

#### c) Datenbank einrichten
1. Gehen Sie zu "SQL Editor"
2. Erstellen Sie ein neues Query
3. Kopieren Sie den Inhalt von `supabase/schema.sql`
4. Führen Sie das Script aus (Run)
5. Überprüfen Sie unter "Table Editor", ob alle Tabellen erstellt wurden:
   - `profiles`
   - `invoices`
   - `audit_logs`

#### d) Storage Bucket erstellen
1. Gehen Sie zu "Storage"
2. Klicken Sie auf "New bucket"
3. Name: `invoices`
4. Public bucket: **Nein** (Private)
5. File size limit: `10MB`
6. Allowed MIME types: `application/pdf, image/png, image/jpeg`
7. Klicken Sie auf "Create bucket"

#### e) Storage Policies prüfen
Die RLS Policies für Storage wurden bereits im SQL-Script erstellt. Überprüfen Sie unter "Storage" > "Policies", ob folgende Policies existieren:
- Users can upload their own invoices
- Users can view their own invoices
- Users can delete their own invoices
- Admins can view all invoices

### 2. Google Cloud & Document AI einrichten

#### a) Google Cloud Projekt erstellen
1. Gehen Sie zu [console.cloud.google.com](https://console.cloud.google.com)
2. Erstellen Sie ein neues Projekt:
   - Name: `rechnungspruefer-ai`
   - Standort: Ihre Organisation (optional)
3. Notieren Sie die **Project ID** → `GOOGLE_CLOUD_PROJECT_ID`

#### b) Document AI API aktivieren
1. Öffnen Sie "APIs & Services" > "Library"
2. Suchen Sie nach "Document AI API"
3. Klicken Sie auf "Enable"
4. Warten Sie bis die API aktiviert ist

#### c) Document AI Processor erstellen
1. Gehen Sie zu "Document AI" > "Processors"
2. Klicken Sie auf "Create Processor"
3. Wählen Sie:
   - Type: **Invoice Parser**
   - Name: `invoice-processor`
   - Region: `eu` (Europa)
4. Klicken Sie auf "Create"
5. Notieren Sie die **Processor ID** aus der URL oder Details
   - Format: `projects/PROJECT_ID/locations/eu/processors/PROCESSOR_ID`
   - Sie brauchen nur den Teil nach `/processors/` → `GOOGLE_DOCUMENT_AI_PROCESSOR_ID`

#### d) Service Account erstellen
1. Gehen Sie zu "IAM & Admin" > "Service Accounts"
2. Klicken Sie auf "Create Service Account"
3. Details:
   - Name: `rechnungspruefer-service`
   - Description: "Service account for invoice processing"
4. Klicken Sie auf "Create and Continue"
5. Rolle zuweisen:
   - Rolle: **Document AI API User**
   - Klicken Sie auf "Continue"
6. Klicken Sie auf "Done"

#### e) Service Account Key erstellen
1. Klicken Sie auf den erstellten Service Account
2. Gehen Sie zum Tab "Keys"
3. Klicken Sie auf "Add Key" > "Create new key"
4. Wählen Sie: **JSON**
5. Klicken Sie auf "Create"
6. Die JSON-Datei wird heruntergeladen
7. ⚠️ **WICHTIG**: Diese Datei enthält sensible Daten!
   - Speichern Sie sie sicher
   - Fügen Sie sie NIEMALS zu Git hinzu
   - Der Inhalt muss in `GOOGLE_APPLICATION_CREDENTIALS_JSON` als String

#### f) JSON-Credentials vorbereiten
1. Öffnen Sie die heruntergeladene JSON-Datei
2. Kopieren Sie den **gesamten Inhalt**
3. Minifizieren Sie das JSON (entfernen Sie alle Zeilenumbrüche)
4. Das Resultat kommt in die `.env.local`:
   ```
   GOOGLE_APPLICATION_CREDENTIALS_JSON={"type":"service_account",...ganze JSON...}
   ```

### 3. OpenAI API Key erhalten

#### a) OpenAI Account erstellen
1. Gehen Sie zu [platform.openai.com](https://platform.openai.com)
2. Registrieren Sie sich oder melden Sie sich an
3. Gehen Sie zu [platform.openai.com/api-keys](https://platform.openai.com/api-keys)

#### b) API Key erstellen
1. Klicken Sie auf "Create new secret key"
2. Name: `rechnungspruefer`
3. Klicken Sie auf "Create secret key"
4. ⚠️ **WICHTIG**: Kopieren Sie den Key sofort!
   - Er wird nur einmal angezeigt
   - Format: `sk-proj-...`
5. Speichern Sie ihn in → `OPENAI_API_KEY`

#### c) Billing einrichten
1. Gehen Sie zu "Settings" > "Billing"
2. Fügen Sie eine Zahlungsmethode hinzu
3. Setzen Sie ein monatliches Limit (empfohlen: 50-100€)

#### d) Kosten-Schätzung
- GPT-4 Mini: ~$0.15 per 1M input tokens
- Durchschnittlich pro Rechnung: ~$0.01-0.03
- Für 1000 Rechnungen/Monat: ~$10-30

### 4. Projekt lokal einrichten

#### a) Repository klonen
```bash
git clone <repository-url>
cd rechnungspruefer
```

#### b) Dependencies installieren
```bash
npm install
```

#### c) Environment Variables konfigurieren
```bash
cp .env.example .env.local
```

Dann `.env.local` bearbeiten und alle Werte eintragen:
```env
NEXT_PUBLIC_SUPABASE_URL=https://cebcjvxpqmhqfylzizjm.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbG...
SUPABASE_SERVICE_ROLE_KEY=eyJhbG...
OPENAI_API_KEY=sk-proj-...
GOOGLE_CLOUD_PROJECT_ID=master-works-475708-t0
GOOGLE_DOCUMENT_AI_PROCESSOR_ID=f599fb1eec70064e
GOOGLE_APPLICATION_CREDENTIALS_JSON={"type":"service_account",...}
```

#### d) Entwicklungsserver starten
```bash
npm run dev
```

Die App läuft nun auf: `http://localhost:3000`

### 5. Ersten Test durchführen

#### a) Account erstellen
1. Öffnen Sie `http://localhost:3000`
2. Sie werden zu `/login` weitergeleitet
3. Klicken Sie auf "Registrieren"
4. Geben Sie ein:
   - E-Mail
   - Vollständiger Name
   - Firmenname (optional)
   - Passwort (mind. 6 Zeichen)
5. Klicken Sie auf "Registrieren"

#### b) E-Mail bestätigen
1. Überprüfen Sie Ihr E-Mail-Postfach
2. Klicken Sie auf den Bestätigungslink von Supabase
3. Kehren Sie zur Login-Seite zurück
4. Melden Sie sich an

#### c) Erste Rechnung hochladen
1. Sie sollten nun im Dashboard sein
2. Klicken Sie auf "Hochladen"
3. Wählen Sie den Rechnungstyp:
   - **Eingangsrechnung**: Rechnung die Sie erhalten haben
   - **Ausgangsrechnung**: Rechnung die Sie erstellt haben
4. Ziehen Sie eine PDF-Rechnung in den Upload-Bereich
5. Oder klicken Sie zum Durchsuchen
6. Klicken Sie auf "Hochladen und analysieren"
7. Warten Sie 10-30 Sekunden auf die Analyse

#### d) Ergebnis prüfen
Die Rechnung sollte nun in der Liste erscheinen mit:
- ✅ Bewertungspunktzahl (0-100)
- ✅ Kritikalitätsstufe (Gut/Warnung/Kritisch)
- ✅ Gefundene Probleme
- ✅ Extrahierte Daten

### 6. Troubleshooting

#### Problem: "Nicht autorisiert" beim Upload
**Lösung:**
1. Prüfen Sie Supabase RLS Policies
2. Stellen Sie sicher, dass Sie angemeldet sind
3. Überprüfen Sie die Auth-Einstellungen in Supabase

#### Problem: "Document AI processing failed"
**Lösung:**
1. Überprüfen Sie, ob Document AI API aktiviert ist
2. Prüfen Sie Service Account Berechtigungen
3. Validieren Sie die JSON-Credentials
4. Überprüfen Sie die Processor ID

#### Problem: "OpenAI analysis failed"
**Lösung:**
1. Prüfen Sie OpenAI API Key
2. Überprüfen Sie Billing und Limits
3. Schauen Sie sich die API-Logs an
4. Reduzieren Sie ggf. die Textmenge

#### Problem: Upload schlägt fehl
**Lösung:**
1. Datei muss < 10MB sein
2. Nur PDF, PNG, JPEG erlaubt
3. Prüfen Sie Storage Policies in Supabase
4. Überprüfen Sie Browser-Konsole auf Fehler

### 7. Production Deployment

#### Vorbereitung
1. Erstellen Sie Production-Umgebung in Supabase
2. Generieren Sie neue API Keys für Production
3. Erstellen Sie separaten OpenAI API Key
4. Verwenden Sie separaten Google Cloud Processor

#### Vercel Deployment
```bash
# Vercel CLI installieren
npm install -g vercel

# Login
vercel login

# Projekt verknüpfen
vercel link

# Environment Variables hinzufügen
vercel env add NEXT_PUBLIC_SUPABASE_URL
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY
vercel env add SUPABASE_SERVICE_ROLE_KEY
vercel env add OPENAI_API_KEY
vercel env add GOOGLE_CLOUD_PROJECT_ID
vercel env add GOOGLE_DOCUMENT_AI_PROCESSOR_ID
vercel env add GOOGLE_APPLICATION_CREDENTIALS_JSON

# Deploy
vercel --prod
```

### 8. Sicherheit Best Practices

✅ **DO's:**
- Verwenden Sie starke, einzigartige Passwörter
- Aktivieren Sie 2FA für alle Cloud-Accounts
- Rotieren Sie API-Keys regelmäßig
- Monitoring und Alerts einrichten
- Regelmäßige Backups der Datenbank
- HTTPS in Production verwenden
- Rate Limiting implementieren

❌ **DON'Ts:**
- Service Role Key niemals im Frontend
- API Keys nicht in Git committen
- Keine sensiblen Daten in Logs
- Production-Keys nicht in Development
- Keine öffentlichen Storage Buckets

### 9. Kosten-Übersicht

**Monatliche Kosten bei 1000 Rechnungen:**
- Supabase Free Tier: 0€ (bis 500MB DB, 1GB Storage)
- Supabase Pro: 25€ (8GB DB, 100GB Storage)
- Google Document AI: ~20-30€ (erste 1000 Seiten frei)
- OpenAI GPT-4 Mini: ~10-30€
- Vercel Hobby: 0€
- Vercel Pro: 20€

**Gesamt: 30-105€/Monat** je nach Tarif und Nutzung

### 10. Support & Hilfe

Bei Problemen:
1. Überprüfen Sie die Logs (Browser Console & API Logs)
2. Konsultieren Sie die Dokumentation
3. Suchen Sie in den GitHub Issues
4. Erstellen Sie ein neues Issue mit:
   - Fehlermeldung
   - Steps to reproduce
   - Environment (Browser, OS, etc.)
   - Logs (ohne sensible Daten!)

---

**Viel Erfolg mit Ihrem Rechnungsprüfer! 🚀**
