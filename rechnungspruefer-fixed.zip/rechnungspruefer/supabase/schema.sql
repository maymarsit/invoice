-- Rechnungsprüfer Database Schema
-- This schema includes Row Level Security (RLS) policies for maximum security

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- User Roles Enum
CREATE TYPE user_role AS ENUM ('admin', 'user');

-- Invoice Types Enum
CREATE TYPE invoice_type AS ENUM ('eingangsrechnung', 'ausgangsrechnung');

-- Criticality Levels Enum
CREATE TYPE criticality_level AS ENUM ('kritisch', 'warnung', 'gut');

-- Status Enum
CREATE TYPE invoice_status AS ENUM ('pending', 'processing', 'completed', 'failed');

-- ============================================
-- PROFILES TABLE (extends Supabase auth.users)
-- ============================================
CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL UNIQUE,
    full_name TEXT,
    role user_role DEFAULT 'user' NOT NULL,
    company_name TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on profiles
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Profiles RLS Policies
CREATE POLICY "Users can view their own profile"
    ON profiles FOR SELECT
    USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
    ON profiles FOR UPDATE
    USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles"
    ON profiles FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE id = auth.uid() AND role = 'admin'
        )
    );

-- ============================================
-- INVOICES TABLE
-- ============================================
CREATE TABLE invoices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    
    -- File Information
    file_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_size INTEGER NOT NULL,
    file_type TEXT NOT NULL,
    
    -- Invoice Basic Info
    invoice_type invoice_type NOT NULL,
    invoice_number TEXT,
    invoice_date DATE,
    due_date DATE,
    
    -- Parties
    supplier_name TEXT,
    supplier_address TEXT,
    supplier_ust_id TEXT,
    customer_name TEXT,
    customer_address TEXT,
    customer_ust_id TEXT,
    
    -- Financial Information
    net_amount DECIMAL(12, 2),
    tax_amount DECIMAL(12, 2),
    tax_rate DECIMAL(5, 2),
    gross_amount DECIMAL(12, 2),
    
    -- Analysis Results
    overall_score INTEGER CHECK (overall_score >= 0 AND overall_score <= 100),
    criticality criticality_level,
    status invoice_status DEFAULT 'pending',
    
    -- Raw Data (encrypted JSON)
    raw_ocr_data JSONB,
    analysis_data JSONB,
    
    -- Issues Found
    issues JSONB DEFAULT '[]'::jsonb,
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    processed_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX idx_invoices_user_id ON invoices(user_id);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_invoices_created_at ON invoices(created_at DESC);
CREATE INDEX idx_invoices_criticality ON invoices(criticality);
CREATE INDEX idx_invoices_invoice_number ON invoices(invoice_number);

-- Enable RLS on invoices
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;

-- Invoices RLS Policies
CREATE POLICY "Users can view their own invoices"
    ON invoices FOR SELECT
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own invoices"
    ON invoices FOR INSERT
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own invoices"
    ON invoices FOR UPDATE
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own invoices"
    ON invoices FOR DELETE
    USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all invoices"
    ON invoices FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE id = auth.uid() AND role = 'admin'
        )
    );

-- ============================================
-- AUDIT LOG TABLE
-- ============================================
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    invoice_id UUID REFERENCES invoices(id) ON DELETE CASCADE,
    action TEXT NOT NULL,
    details JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create index
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_invoice_id ON audit_logs(invoice_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at DESC);

-- Enable RLS on audit_logs
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Audit Logs RLS Policies
CREATE POLICY "Admins can view all audit logs"
    ON audit_logs FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE id = auth.uid() AND role = 'admin'
        )
    );

-- ============================================
-- FUNCTIONS AND TRIGGERS
-- ============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for profiles
CREATE TRIGGER update_profiles_updated_at
    BEFORE UPDATE ON profiles
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Trigger for invoices
CREATE TRIGGER update_invoices_updated_at
    BEFORE UPDATE ON invoices
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Function to create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (id, email, full_name)
    VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'full_name');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to create profile on signup
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_user();

-- Function to log actions (can be called from Edge Functions)
CREATE OR REPLACE FUNCTION log_action(
    p_user_id UUID,
    p_invoice_id UUID,
    p_action TEXT,
    p_details JSONB,
    p_ip_address INET,
    p_user_agent TEXT
)
RETURNS void AS $$
BEGIN
    INSERT INTO audit_logs (user_id, invoice_id, action, details, ip_address, user_agent)
    VALUES (p_user_id, p_invoice_id, p_action, p_details, p_ip_address, p_user_agent);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================
-- STORAGE BUCKETS
-- ============================================
-- These need to be created in Supabase Dashboard or via SQL:

-- Create storage bucket for invoices
INSERT INTO storage.buckets (id, name, public)
VALUES ('invoices', 'invoices', false);

-- Storage RLS Policies for invoices bucket
CREATE POLICY "Users can upload their own invoices"
ON storage.objects FOR INSERT
WITH CHECK (
    bucket_id = 'invoices' AND
    auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can view their own invoices"
ON storage.objects FOR SELECT
USING (
    bucket_id = 'invoices' AND
    auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can delete their own invoices"
ON storage.objects FOR DELETE
USING (
    bucket_id = 'invoices' AND
    auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Admins can view all invoices"
ON storage.objects FOR SELECT
USING (
    bucket_id = 'invoices' AND
    EXISTS (
        SELECT 1 FROM profiles
        WHERE id = auth.uid() AND role = 'admin'
    )
);

-- ============================================
-- VIEWS FOR DASHBOARD
-- ============================================

-- View for user statistics
CREATE OR REPLACE VIEW user_statistics AS
SELECT 
    user_id,
    COUNT(*) as total_invoices,
    COUNT(*) FILTER (WHERE criticality = 'gut') as good_invoices,
    COUNT(*) FILTER (WHERE criticality = 'warnung') as warning_invoices,
    COUNT(*) FILTER (WHERE criticality = 'kritisch') as critical_invoices,
    AVG(overall_score) as average_score,
    COUNT(*) FILTER (WHERE created_at > NOW() - INTERVAL '30 days') as invoices_last_30_days
FROM invoices
GROUP BY user_id;

-- Grant access to the view
GRANT SELECT ON user_statistics TO authenticated;
