# 🚀 Rechnungsprüfer - Quick Start

## Was ist Rechnungsprüfer?

Ein professionelles, KI-gestütztes System zur automatischen Prüfung deutscher Rechnungen. Das System:

✅ Extrahiert automatisch alle Rechnungsdaten (OCR)  
✅ Prüft Compliance gemäß § 14 UStG  
✅ Bewertet mathematische Korrektheit  
✅ Validiert USt-IdNr Format  
✅ Generiert einen 0-100 Bewertungsscore  
✅ Zeigt kritische Probleme auf  

## 🎯 Technologie-Stack

**Frontend:**
- Next.js 14 (React)
- TypeScript
- Tailwind CSS
- Lucide Icons

**Backend:**
- Supabase (PostgreSQL + Auth + Storage)
- Next.js API Routes
- Google Document AI (OCR)
- OpenAI GPT-4 Mini (Analyse)

**Security:**
- Row Level Security (RLS)
- HTTPS/TLS Encryption
- Secure Environment Variables
- Audit Logging

## ⚡ 5-Minuten Start

```bash
# 1. Klonen
git clone <repo-url>
cd rechnungspruefer

# 2. Dependencies
npm install

# 3. Environment Variables
cp .env.example .env.local
# Dann .env.local mit Ihren Keys ausfüllen

# 4. Starten
npm run dev

# 5. Öffnen
# http://localhost:3000
```

## 📁 Wichtige Dateien

```
rechnungspruefer/
├── src/
│   ├── app/
│   │   ├── api/              # Backend API Routes
│   │   ├── dashboard/        # Hauptseite
│   │   └── login/           # Authentifizierung
│   ├── components/          # React Komponenten
│   ├── lib/                 # Utilities & AI Integration
│   └── types/               # TypeScript Definitionen
├── supabase/
│   └── schema.sql           # Datenbank Setup
├── .env.local               # Ihre Secrets (NICHT committen!)
├── README.md                # Vollständige Dokumentation
└── SETUP.md                 # Detaillierte Anleitung
```

## 🔑 Benötigte API Keys

1. **Supabase** (gratis)
   - URL + Anon Key (öffentlich)
   - Service Role Key (geheim!)

2. **Google Cloud** (erste 1000 Seiten gratis/Monat)
   - Project ID
   - Document AI Processor ID
   - Service Account JSON

3. **OpenAI** (Pay-as-you-go)
   - API Key für GPT-4 Mini
   - ~$0.01-0.03 pro Rechnung

## 📊 Features im Detail

### Upload & OCR
- Drag & Drop Interface
- PDF, PNG, JPEG Support
- Max 10MB pro Datei
- Automatische OCR-Extraktion

### Intelligente Analyse
- 5 Bewertungskategorien:
  1. Pflichtfelder (30 Punkte)
  2. USt-IdNr (20 Punkte)
  3. Mathematik (25 Punkte)
  4. Datumslogik (10 Punkte)
  5. Format (15 Punkte)

### Dashboard
- Übersicht aller Rechnungen
- Statistiken & Trends
- Filterung & Suche
- Export-Optionen

### Sicherheit
- Verschlüsselte Speicherung
- User Isolation (RLS)
- Audit Logging
- GDPR-konform

## 🐛 Häufige Probleme

**Upload funktioniert nicht?**
→ Prüfen Sie Supabase Storage RLS Policies

**Analyse schlägt fehl?**
→ Überprüfen Sie Google Cloud & OpenAI API Keys

**Login geht nicht?**
→ Kontrollieren Sie Supabase Auth Settings

**Deployment-Probleme?**
→ Environment Variables in Vercel korrekt gesetzt?

## 📚 Weitere Ressourcen

- **README.md**: Vollständige Dokumentation
- **SETUP.md**: Schritt-für-Schritt Anleitung
- **supabase/schema.sql**: Datenbank-Schema
- **.env.example**: Alle benötigten Variablen

## 🔒 Sicherheitshinweise

⚠️ **NIEMALS committen:**
- .env.local
- Service Account JSONs
- API Keys
- Service Role Keys

✅ **Immer beachten:**
- Service Role Key nur serverseitig
- HTTPS in Production
- Regelmäßige Key-Rotation
- Monitoring einrichten

## 💰 Kosten-Kalkulation

**Für 1000 Rechnungen/Monat:**

| Service | Kosten |
|---------|--------|
| Supabase Free | 0€ |
| Google Document AI | ~20-30€ |
| OpenAI GPT-4 Mini | ~10-30€ |
| Vercel Hobby | 0€ |
| **TOTAL** | **30-60€/Monat** |

## 🎓 Nächste Schritte

1. ✅ Folgen Sie SETUP.md für die Installation
2. ✅ Testen Sie mit echten Rechnungen
3. ✅ Passen Sie Scoring-Logik an Ihre Bedürfnisse an
4. ✅ Implementieren Sie zusätzliche Features
5. ✅ Deployen Sie auf Vercel

## 📞 Support

Bei Fragen oder Problemen:
1. Konsultieren Sie README.md und SETUP.md
2. Überprüfen Sie die Logs
3. Suchen Sie in den Issues
4. Erstellen Sie ein neues Issue

---

**Viel Erfolg! 🎉**

Erstellt mit ❤️ für deutsche Unternehmen
