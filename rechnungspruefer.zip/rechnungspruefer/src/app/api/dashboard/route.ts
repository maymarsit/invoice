import { NextRequest, NextResponse } from 'next/server';
import { getServerSupabase } from '@/lib/supabase';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const supabase = await getServerSupabase();
    const { data: { user }, error: authError } = await supabase.auth.getUser();

    if (authError || !user) {
      return NextResponse.json(
        { error: 'Nicht autorisiert' },
        { status: 401 }
      );
    }

    // Get user statistics
    const { data: stats, error: statsError } = await supabase
      .from('user_statistics')
      .select('*')
      .eq('user_id', user.id)
      .single();

    if (statsError && statsError.code !== 'PGRST116') {
      console.error('Stats error:', statsError);
    }

    // Get recent invoices
    const { data: recentInvoices, error: invoicesError } = await supabase
      .from('invoices')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(10);

    if (invoicesError) {
      console.error('Invoices error:', invoicesError);
    }

    // Calculate statistics if view doesn't exist yet
    const dashboardStats = {
      total_invoices: stats?.total_invoices || 0,
      good_invoices: stats?.good_invoices || 0,
      warning_invoices: stats?.warning_invoices || 0,
      critical_invoices: stats?.critical_invoices || 0,
      average_score: stats?.average_score || 0,
      invoices_last_30_days: stats?.invoices_last_30_days || 0,
      recent_invoices: recentInvoices || [],
    };

    return NextResponse.json(dashboardStats);

  } catch (error) {
    console.error('Dashboard API error:', error);
    return NextResponse.json(
      { error: 'Ein unerwarteter Fehler ist aufgetreten' },
      { status: 500 }
    );
  }
}
