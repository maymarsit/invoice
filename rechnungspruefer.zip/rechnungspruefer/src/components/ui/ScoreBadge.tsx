import React from 'react';
import { CriticalityLevel } from '@/types';

interface ScoreBadgeProps {
  score: number;
  criticality: CriticalityLevel;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
}

export const ScoreBadge: React.FC<ScoreBadgeProps> = ({
  score,
  criticality,
  size = 'md',
  showLabel = false,
}) => {
  const sizeClasses = {
    sm: 'score-badge-sm',
    md: 'score-badge-md',
    lg: 'score-badge-lg',
  };

  const colorClasses = {
    kritisch: 'bg-danger-100 text-danger-700 border-2 border-danger-300',
    warnung: 'bg-warning-100 text-warning-700 border-2 border-warning-300',
    gut: 'bg-success-100 text-success-700 border-2 border-success-300',
  };

  const labels = {
    kritisch: 'Kritisch',
    warnung: 'Warnung',
    gut: 'Gut',
  };

  return (
    <div className="flex flex-col items-center">
      <div className={`${sizeClasses[size]} ${colorClasses[criticality]}`}>
        {score}
      </div>
      {showLabel && (
        <span className={`mt-2 text-sm font-medium ${
          criticality === 'kritisch' ? 'text-danger-700' :
          criticality === 'warnung' ? 'text-warning-700' :
          'text-success-700'
        }`}>
          {labels[criticality]}
        </span>
      )}
    </div>
  );
};
