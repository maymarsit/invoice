import React from 'react';
import { Invoice } from '@/types';
import { ScoreBadge } from './ScoreBadge';
import { FileText, Calendar, Euro, Trash2, Eye, Download } from 'lucide-react';
import { format } from 'date-fns';

interface InvoiceCardProps {
  invoice: Invoice;
  onView?: (invoice: Invoice) => void;
  onDelete?: (invoiceId: string) => void;
  onDownload?: (invoice: Invoice) => void;
}

export const InvoiceCard: React.FC<InvoiceCardProps> = ({
  invoice,
  onView,
  onDelete,
  onDownload,
}) => {
  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'N/A';
    try {
      return format(new Date(dateString), 'dd.MM.yyyy');
    } catch {
      return 'N/A';
    }
  };

  const formatCurrency = (amount: number | null) => {
    if (amount === null) return 'N/A';
    return new Intl.NumberFormat('de-DE', {
      style: 'currency',
      currency: 'EUR',
    }).format(amount);
  };

  const getStatusBadge = () => {
    const statusConfig = {
      pending: { label: 'Ausstehend', color: 'bg-gray-100 text-gray-700' },
      processing: { label: 'Wird verarbeitet', color: 'bg-blue-100 text-blue-700' },
      completed: { label: 'Abgeschlossen', color: 'bg-success-100 text-success-700' },
      failed: { label: 'Fehlgeschlagen', color: 'bg-danger-100 text-danger-700' },
    };

    const config = statusConfig[invoice.status];
    
    return (
      <span className={`badge ${config.color}`}>
        {config.label}
      </span>
    );
  };

  return (
    <div className="card-hover">
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start space-x-3 flex-1">
            <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <FileText className="w-5 h-5 text-primary-600" />
            </div>
            
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-gray-900 truncate mb-1">
                {invoice.file_name}
              </h3>
              <p className="text-sm text-gray-500">
                {invoice.invoice_type === 'eingangsrechnung' ? 'Eingangsrechnung' : 'Ausgangsrechnung'}
              </p>
              {invoice.invoice_number && (
                <p className="text-sm text-gray-600 mt-1">
                  Nr: {invoice.invoice_number}
                </p>
              )}
            </div>
          </div>

          {invoice.overall_score !== null && invoice.criticality && (
            <ScoreBadge
              score={invoice.overall_score}
              criticality={invoice.criticality}
              size="sm"
            />
          )}
        </div>

        <div className="space-y-2 mb-4">
          {invoice.invoice_date && (
            <div className="flex items-center text-sm text-gray-600">
              <Calendar className="w-4 h-4 mr-2" />
              <span>Datum: {formatDate(invoice.invoice_date)}</span>
            </div>
          )}
          
          {invoice.gross_amount !== null && (
            <div className="flex items-center text-sm text-gray-600">
              <Euro className="w-4 h-4 mr-2" />
              <span>Betrag: {formatCurrency(invoice.gross_amount)}</span>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div>{getStatusBadge()}</div>
          
          <div className="flex items-center space-x-2">
            {onDownload && invoice.status === 'completed' && (
              <button
                onClick={() => onDownload(invoice)}
                className="p-2 text-gray-600 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                title="Herunterladen"
              >
                <Download className="w-4 h-4" />
              </button>
            )}
            
            {onView && (
              <button
                onClick={() => onView(invoice)}
                className="p-2 text-gray-600 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors"
                title="Ansehen"
              >
                <Eye className="w-4 h-4" />
              </button>
            )}
            
            {onDelete && (
              <button
                onClick={() => onDelete(invoice.id)}
                className="p-2 text-gray-600 hover:text-danger-600 hover:bg-danger-50 rounded-lg transition-colors"
                title="Löschen"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {invoice.issues && invoice.issues.length > 0 && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <p className="text-sm font-medium text-gray-700 mb-2">
              Gefundene Probleme:
            </p>
            <div className="space-y-1">
              {invoice.issues.slice(0, 2).map((issue, index) => (
                <div
                  key={index}
                  className="text-xs text-gray-600 flex items-start"
                >
                  <span className={`inline-block w-2 h-2 rounded-full mr-2 mt-1 flex-shrink-0 ${
                    issue.severity === 'kritisch' ? 'bg-danger-500' :
                    issue.severity === 'warnung' ? 'bg-warning-500' :
                    'bg-primary-500'
                  }`} />
                  <span>{issue.description}</span>
                </div>
              ))}
              {invoice.issues.length > 2 && (
                <p className="text-xs text-gray-500 ml-4">
                  +{invoice.issues.length - 2} weitere...
                </p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
