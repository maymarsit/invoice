// Database Types
export type UserRole = 'admin' | 'user';
export type InvoiceType = 'eingangsrechnung' | 'ausgangsrechnung';
export type CriticalityLevel = 'kritisch' | 'warnung' | 'gut';
export type InvoiceStatus = 'pending' | 'processing' | 'completed' | 'failed';

// Database Tables
export interface Profile {
  id: string;
  email: string;
  full_name: string | null;
  role: UserRole;
  company_name: string | null;
  created_at: string;
  updated_at: string;
}

export interface Invoice {
  id: string;
  user_id: string;
  file_name: string;
  file_path: string;
  file_size: number;
  file_type: string;
  invoice_type: InvoiceType;
  invoice_number: string | null;
  invoice_date: string | null;
  due_date: string | null;
  supplier_name: string | null;
  supplier_address: string | null;
  supplier_ust_id: string | null;
  customer_name: string | null;
  customer_address: string | null;
  customer_ust_id: string | null;
  net_amount: number | null;
  tax_amount: number | null;
  tax_rate: number | null;
  gross_amount: number | null;
  overall_score: number | null;
  criticality: CriticalityLevel | null;
  status: InvoiceStatus;
  raw_ocr_data: any;
  analysis_data: AnalysisData | null;
  issues: Issue[];
  created_at: string;
  processed_at: string | null;
  updated_at: string;
}

export interface AuditLog {
  id: string;
  user_id: string | null;
  invoice_id: string | null;
  action: string;
  details: any;
  ip_address: string | null;
  user_agent: string | null;
  created_at: string;
}

// Analysis Types
export interface Issue {
  category: string;
  severity: 'kritisch' | 'warnung' | 'info';
  description: string;
  field?: string;
  details?: string;
}

export interface AnalysisData {
  pflichtfelder_score: number;
  ust_idnr_score: number;
  mathematik_score: number;
  datum_score: number;
  format_score: number;
  pflichtfelder_details: {
    present: string[];
    missing: string[];
  };
  ust_validation: {
    supplier_valid: boolean;
    customer_valid: boolean;
    format_correct: boolean;
  };
  math_validation: {
    calculations_correct: boolean;
    net_plus_tax_equals_gross: boolean;
    tax_rate_correct: boolean;
    difference?: number;
  };
  date_validation: {
    invoice_date_present: boolean;
    due_date_valid: boolean;
    dates_logical: boolean;
  };
  format_check: {
    readable: boolean;
    complete: boolean;
    structured: boolean;
  };
  recommendations: string[];
}

// API Request/Response Types
export interface UploadInvoiceRequest {
  file: File;
  invoice_type: InvoiceType;
}

export interface UploadInvoiceResponse {
  success: boolean;
  invoice_id?: string;
  message?: string;
  error?: string;
}

export interface AnalyzeInvoiceRequest {
  invoice_id: string;
}

export interface AnalyzeInvoiceResponse {
  success: boolean;
  invoice?: Invoice;
  error?: string;
}

// Dashboard Statistics
export interface DashboardStats {
  total_invoices: number;
  good_invoices: number;
  warning_invoices: number;
  critical_invoices: number;
  average_score: number;
  invoices_last_30_days: number;
  recent_invoices: Invoice[];
}

// Form Types
export interface LoginFormData {
  email: string;
  password: string;
}

export interface RegisterFormData {
  email: string;
  password: string;
  full_name: string;
  company_name?: string;
}

// Utility Types
export interface SelectOption {
  value: string;
  label: string;
}

export interface PaginationParams {
  page: number;
  limit: number;
}

export interface SortParams {
  field: string;
  direction: 'asc' | 'desc';
}

// Component Props Types
export interface InvoiceCardProps {
  invoice: Invoice;
  onView?: (invoice: Invoice) => void;
  onDelete?: (invoiceId: string) => void;
}

export interface StatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color: 'primary' | 'success' | 'warning' | 'danger';
  trend?: {
    value: number;
    isPositive: boolean;
  };
}

export interface ScoreBadgeProps {
  score: number;
  criticality: CriticalityLevel;
  size?: 'sm' | 'md' | 'lg';
}

// Constants
export const CRITICALITY_COLORS = {
  kritisch: 'danger',
  warnung: 'warning',
  gut: 'success',
} as const;

export const CRITICALITY_LABELS = {
  kritisch: 'Kritisch',
  warnung: 'Warnung',
  gut: 'Gut',
} as const;

export const INVOICE_TYPE_LABELS = {
  eingangsrechnung: 'Eingangsrechnung',
  ausgangsrechnung: 'Ausgangsrechnung',
} as const;

export const STATUS_LABELS = {
  pending: 'Ausstehend',
  processing: 'Wird verarbeitet',
  completed: 'Abgeschlossen',
  failed: 'Fehlgeschlagen',
} as const;
