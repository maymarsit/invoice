# Rechnungsprüfer 🧾

Professionelle intelligente Rechnungsprüfung für deutsche Unternehmen mit KI-Unterstützung.

## 🎯 Features

- **🔍 Automatische OCR-Erkennung**: Extraktion von Rechnungsdaten mit Google Document AI
- **🤖 KI-Analyse**: Intelligente Bewertung mit OpenAI GPT-4 Mini
- **✅ Compliance-Prüfung**: Validierung gemäß § 14 UStG
- **📊 Dashboard**: Übersichtliche Statistiken und Auswertungen
- **🔒 Sicherheit**: GDPR-konforme Datenspeicherung mit Row Level Security
- **📱 Responsive Design**: Perfekt auf Desktop und Mobile

## 📋 Bewertungskriterien

Das System bewertet Rechnungen auf einer Skala von 0-100 Punkten:

1. **Pflichtfelder (30 Punkte)**: Vollständigkeit der Pflichtangaben nach § 14 UStG
2. **USt-IdNr Validierung (20 Punkte)**: Format und Gültigkeit der Umsatzsteuer-ID
3. **Mathematische Richtigkeit (25 Punkte)**: Korrektheit der Berechnungen
4. **Datumsvalidierung (10 Punkte)**: Logik von Rechnungs- und Fälligkeitsdatum
5. **Format & Lesbarkeit (15 Punkte)**: Strukturierung und Vollständigkeit

### Kritikalitätsstufen

- 🟢 **GUT** (71-100 Punkte): Rechnung erfüllt alle Anforderungen
- 🟡 **WARNUNG** (41-70 Punkte): Kleinere Mängel vorhanden
- 🔴 **KRITISCH** (0-40 Punkte): Schwerwiegende Probleme

## 🚀 Installation

### Voraussetzungen

- Node.js 18+ und npm
- Supabase Account
- Google Cloud Account mit Document AI API
- OpenAI API Key

### 1. Repository klonen

```bash
git clone <repository-url>
cd rechnungspruefer
```

### 2. Dependencies installieren

```bash
npm install
```

### 3. Umgebungsvariablen konfigurieren

Erstellen Sie eine `.env.local` Datei im Root-Verzeichnis:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://ihr-projekt.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=ihr-anon-key
SUPABASE_SERVICE_ROLE_KEY=ihr-service-role-key

# OpenAI
OPENAI_API_KEY=sk-proj-...

# Google Document AI
GOOGLE_CLOUD_PROJECT_ID=ihr-projekt-id
GOOGLE_DOCUMENT_AI_PROCESSOR_ID=ihr-processor-id
GOOGLE_APPLICATION_CREDENTIALS_JSON={"type":"service_account",...}

# App Configuration
NEXT_PUBLIC_APP_URL=http://localhost:3000
MAX_FILE_SIZE=10485760
ALLOWED_FILE_TYPES=application/pdf,image/png,image/jpeg
```

### 4. Supabase Datenbank einrichten

1. Öffnen Sie Supabase SQL Editor
2. Führen Sie das Schema aus: `supabase/schema.sql`
3. Erstellen Sie den Storage Bucket "invoices" im Dashboard

### 5. Google Document AI einrichten

1. Erstellen Sie ein Projekt in Google Cloud Console
2. Aktivieren Sie die Document AI API
3. Erstellen Sie einen Document AI Processor (Type: Invoice Parser)
4. Erstellen Sie ein Service Account und laden Sie die JSON-Credentials herunter
5. Kopieren Sie den JSON-Inhalt in die `GOOGLE_APPLICATION_CREDENTIALS_JSON` Variable

### 6. Entwicklungsserver starten

```bash
npm run dev
```

Die Anwendung ist nun unter `http://localhost:3000` erreichbar.

## 🏗️ Projektstruktur

```
rechnungspruefer/
├── src/
│   ├── app/
│   │   ├── api/              # API Routes
│   │   │   ├── upload/       # Datei-Upload
│   │   │   ├── analyze/      # Rechnungsanalyse
│   │   │   ├── dashboard/    # Dashboard-Daten
│   │   │   └── invoices/     # Rechnungsverwaltung
│   │   ├── dashboard/        # Dashboard Seite
│   │   ├── login/           # Login Seite
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   └── globals.css
│   ├── components/
│   │   ├── ui/              # UI Komponenten
│   │   └── upload/          # Upload Komponenten
│   ├── lib/
│   │   ├── supabase.ts      # Supabase Client
│   │   ├── documentai.ts    # Google Document AI
│   │   └── openai-analysis.ts # OpenAI Analyse
│   └── types/
│       └── index.ts         # TypeScript Typen
├── supabase/
│   └── schema.sql           # Datenbankschema
├── package.json
├── tsconfig.json
├── tailwind.config.js
└── next.config.js
```

## 🔒 Sicherheit

### Implementierte Sicherheitsmaßnahmen

1. **Row Level Security (RLS)**: Benutzer können nur ihre eigenen Daten sehen
2. **Verschlüsselte Speicherung**: Alle Dateien werden sicher in Supabase Storage gespeichert
3. **API-Authentifizierung**: Alle API-Routes prüfen die Benutzerauthentifizierung
4. **Audit Logging**: Alle wichtigen Aktionen werden protokolliert
5. **Input Validation**: Dateigrößen und -typen werden validiert
6. **Environment Variables**: Sensible Daten nur serverseitig
7. **Security Headers**: HSTS, X-Frame-Options, CSP, etc.

### Best Practices

- ✅ Service Role Key niemals im Frontend verwenden
- ✅ Regelmäßige Updates der Dependencies
- ✅ Rate Limiting für API-Endpoints implementieren
- ✅ Backup-Strategie für Datenbank und Dateien
- ✅ Monitoring und Error Tracking einrichten

## 📊 API Endpunkte

### POST `/api/upload`
Lädt eine Rechnung hoch und erstellt einen Datenbankeintrag.

**Request:**
```typescript
FormData {
  file: File,
  invoice_type: 'eingangsrechnung' | 'ausgangsrechnung'
}
```

**Response:**
```typescript
{
  success: boolean,
  invoice_id: string,
  message: string
}
```

### POST `/api/analyze`
Analysiert eine hochgeladene Rechnung.

**Request:**
```typescript
{
  invoice_id: string
}
```

**Response:**
```typescript
{
  success: boolean,
  invoice: Invoice,
  message: string
}
```

### GET `/api/dashboard`
Ruft Dashboard-Statistiken ab.

**Response:**
```typescript
{
  total_invoices: number,
  good_invoices: number,
  warning_invoices: number,
  critical_invoices: number,
  average_score: number,
  invoices_last_30_days: number,
  recent_invoices: Invoice[]
}
```

### DELETE `/api/invoices/[id]`
Löscht eine Rechnung und die zugehörige Datei.

**Response:**
```typescript
{
  success: boolean,
  message: string
}
```

## 🔧 Konfiguration

### Dateigrößenlimits anpassen

In `.env.local`:
```env
MAX_FILE_SIZE=10485760  # 10MB in Bytes
```

### Unterstützte Dateitypen ändern

In `.env.local`:
```env
ALLOWED_FILE_TYPES=application/pdf,image/png,image/jpeg
```

## 🐛 Debugging

### Logs anzeigen

**Supabase Logs:**
```bash
# Im Supabase Dashboard unter "Logs"
```

**Next.js Development Logs:**
```bash
npm run dev
# Logs erscheinen im Terminal
```

### Häufige Probleme

**Problem:** Upload schlägt fehl
- Prüfen Sie die Supabase Storage RLS Policies
- Überprüfen Sie Dateigrößen und -typen
- Kontrollieren Sie die Service Role Key

**Problem:** Analyse hängt
- Erhöhen Sie das `maxDuration` in der API Route
- Prüfen Sie Google Cloud Quotas
- Überprüfen Sie OpenAI API Limits

**Problem:** Login funktioniert nicht
- Kontrollieren Sie Supabase Auth Settings
- Prüfen Sie E-Mail-Bestätigungseinstellungen
- Überprüfen Sie die Supabase URL und Keys

## 📈 Performance-Optimierung

1. **Caching**: Implementieren Sie Redis für API-Responses
2. **Image Optimization**: Nutzen Sie Next.js Image Optimization
3. **Lazy Loading**: Verwenden Sie React.lazy für große Komponenten
4. **Database Indexes**: Erstellen Sie Indexes für häufige Queries
5. **CDN**: Verwenden Sie ein CDN für statische Assets

## 🚀 Deployment

### Vercel Deployment

1. Repository auf GitHub pushen
2. Vercel mit GitHub verbinden
3. Projekt importieren
4. Environment Variables hinzufügen
5. Deploy!

```bash
# Oder via CLI
npm install -g vercel
vercel --prod
```

### Docker Deployment

```dockerfile
# Dockerfile erstellen
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## 📝 Lizenz

Dieses Projekt ist für den internen Gebrauch bestimmt.

## 🤝 Support

Bei Fragen oder Problemen:
1. Überprüfen Sie die Logs
2. Konsultieren Sie die Dokumentation
3. Kontaktieren Sie das Development-Team

## 🎯 Roadmap

- [ ] Admin Dashboard mit Benutzerverwaltung
- [ ] Export-Funktionen (Excel, CSV)
- [ ] E-Mail-Benachrichtigungen
- [ ] Multi-Sprachen Support
- [ ] Mobile App (React Native)
- [ ] Batch-Upload für mehrere Rechnungen
- [ ] KI-Trainingsmodus für verbesserte Genauigkeit
- [ ] API für externe Integration

---

**Version:** 1.0.0  
**Letztes Update:** 2025
